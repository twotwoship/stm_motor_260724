#include "device_driver.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void Uart2_Init(int baud)
{
  double div;
  unsigned int mant;
  unsigned int frac;

  Macro_Set_Bit(RCC->AHB1ENR, 0);
  Macro_Set_Bit(RCC->APB1ENR, 17);
  Macro_Write_Block(GPIOA->MODER, 0xf, 0xa, 4);
  Macro_Write_Block(GPIOA->AFR[0], 0xff, 0x77, 8);
  Macro_Write_Block(GPIOA->PUPDR, 0xf, 0x5, 4);

  volatile unsigned int t = GPIOA->LCKR & 0x7FFF;
  GPIOA->LCKR = (0x1<<16)|t|(0x3<<2);
  GPIOA->LCKR = (0x0<<16)|t|(0x3<<2);
  GPIOA->LCKR = (0x1<<16)|t|(0x3<<2);
  t = GPIOA->LCKR;

  div = PCLK1/(16. * baud);
  mant = (int)div;
  frac = (int)((div - mant) * 16. + 0.5);
  mant += frac >> 4;
  frac &= 0xf;

  USART2->BRR = (mant<<4)|(frac<<0);
  USART2->CR1 = (1<<13)|(0<<12)|(0<<10)|(1<<3)|(1<<2);
  USART2->CR2 = 0<<12;
  USART2->CR3 = 0;
}

void Uart2_Send_Byte(char data)
{
  if(data == '\n')
  {
    while(!Macro_Check_Bit_Set(USART2->SR, 7));
    USART2->DR = 0x0d;
  }
  while(!Macro_Check_Bit_Set(USART2->SR, 7));
  USART2->DR = data;
}

void Uart2_RX_Interrupt_Enable(void)
{
  Macro_Set_Bit(USART2->CR1, 5);
  NVIC_ClearPendingIRQ(38);
  NVIC_SetPriority((IRQn_Type)38, 3);
  NVIC_EnableIRQ(38);
}

volatile unsigned char uart_flag = 0;
volatile unsigned char uart_data = 0;

void Uart_Event_Handle(void)
{
  if(uart_flag)
  {
    uart_flag = 0;
    button_event = BUTTON_UART_CMD;
  }
}
