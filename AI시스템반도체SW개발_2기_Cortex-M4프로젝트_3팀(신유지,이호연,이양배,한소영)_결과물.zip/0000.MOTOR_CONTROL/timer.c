#include "device_driver.h"

#define TIM2_PWM_FREQ	1000

void TIM2_PWM_Init(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 0);

	TIM2->PSC = (unsigned int)(TIMXCLK / (double)(TIM2_PWM_FREQ *  1000) + 0.5) - 1;
	TIM2->ARR = 1000 - 1;

	Macro_Write_Block(TIM2->CCMR1, 0xff, 0x60, 0);
	Macro_Write_Block(TIM2->CCMR1, 0xff, 0x60, 8);

	Macro_Write_Block(TIM2->CCER, 0x3, 0x1, 0);
	Macro_Write_Block(TIM2->CCER, 0x3, 0x1, 4);

	TIM2->CCR1 = 0;
	TIM2->CCR2 = 0;

	Macro_Set_Bit(TIM2->EGR, 0);
	TIM2->CR1 = (0 << 7) | (1 << 4) | (0 << 3) | (1 << 0);
}


#define TIM5_FREQ           10000
#define LONG_PRESS_MS        3000
#define TIM5_MAX		    (LONG_PRESS_MS * 10 - 1)   // ARR = 29999

void TIM5_Init(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 3);

	TIM5->PSC = (unsigned int)(TIMXCLK / (double)TIM5_FREQ + 0.5) - 1;   // 9599
	TIM5->ARR = TIM5_MAX;                                       // 29999

	Macro_Set_Bit(TIM5->EGR, 0);
	Macro_Clear_Bit(TIM5->SR, 0);

	TIM5->CR1 = (0 << 7) | (1 << 4) | (1 << 3) | (0 << 0);
	
}

void TIM5_ISR_Enable(void)
{
	NVIC_ClearPendingIRQ(50);
	Macro_Set_Bit(TIM5->DIER, 0);
	NVIC_SetPriority((IRQn_Type)50, 2);
	NVIC_EnableIRQ(50);
}

void TIM5_Start(void)
{
	Macro_Clear_Bit(TIM5->CR1, 0);
	TIM5->CNT = TIM5_MAX;   // 다운카운트이므로 ARR로 채움 (0 아님)
	Macro_Clear_Bit(TIM5->SR, 0);
	Macro_Set_Bit(TIM5->CR1, 0);
}

void TIM5_Stop(void)
{
	Macro_Clear_Bit(TIM5->CR1, 0);
}