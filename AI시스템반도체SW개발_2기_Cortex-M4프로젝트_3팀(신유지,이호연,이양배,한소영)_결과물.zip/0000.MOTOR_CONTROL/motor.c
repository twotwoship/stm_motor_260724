#include "device_driver.h"
#include <stdio.h>

static MotorState_t pwm_active_state = STOP;

static const unsigned char duty_table[10] = {50, 55, 60, 65, 70, 75, 80, 85, 90, 95};

static MotorState_t new_motor_state = STOP;
static int motor_speed = 50;
static int new_motor_speed = 50;

#define MOTOR_REVERSE_WAIT_MS   200   // 방향 전환(CW<->CCW) 사이 대기시간, 실측 후 조정

static volatile int waiting_reverse = 0;
static MotorState_t pending_state = STOP;

void Motor_Init(void)
{
    // PA0: INPUT1(PIN2)
    // PA1: INPUT2(PIN7)
    // PA7: ENABLE[1:2](PIN1)

    Macro_Set_Bit(RCC->AHB1ENR, 0);

    Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 7*2);
    Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 0*2);
    Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, 1*2);

    Macro_Clear_Bit(GPIOA->OTYPER, 7);
    Macro_Clear_Bit(GPIOA->OTYPER, 0);
    Macro_Clear_Bit(GPIOA->OTYPER, 1);

    Macro_Set_Bit(GPIOA->ODR, 7);
    Macro_Clear_Bit(GPIOA->ODR, 0);
    Macro_Clear_Bit(GPIOA->ODR, 1);

    TIM2_PWM_Init();
}

void Motor_Pin_Output_Low(int pin)
{
    Macro_Write_Block(GPIOA->MODER, 0x3, 0x1, pin*2);   // Output mode
    Macro_Clear_Bit(GPIOA->ODR, pin);
}

void Motor_Pin_PWM(int pin)
{
    Macro_Write_Block(GPIOA->MODER, 0x3, 0x2, pin*2);   // Alternate Function
    Macro_Write_Block(GPIOA->AFR[0], 0xF, 0x1, pin*4); 
}

void Motor_CW(void)
{
    Motor_Pin_Output_Low(0);   
    Motor_Pin_PWM(1);         
    pwm_active_state = CW;
    Motor_Set_Duty(50);
}

void Motor_CCW(void)
{
    Motor_Pin_PWM(0);         
    Motor_Pin_Output_Low(1);   
    pwm_active_state = CCW;
    Motor_Set_Duty(50);
}

void Motor_Stop(void)
{
    Motor_Pin_Output_Low(0);
    Motor_Pin_Output_Low(1);
    pwm_active_state = STOP;
}

int Motor_Is_Waiting(void)
{
    return waiting_reverse;
}

// 방향 전환(CW<->CCW) 요청 시 호출: 즉시 정지시키고 SysTick으로 대기를 시작(논블로킹)
void Motor_Wait(void)
{
    Motor_Stop();
    pending_state = new_motor_state;
    waiting_reverse = 1;
    SysTick_Run(MOTOR_REVERSE_WAIT_MS);
}

static void Apply_Motor_State(MotorState_t state)
{
    switch(state)
    {
        case CW:
            Motor_CW();
            printf("정회전(CW)\n");
            break;
        case CCW:
            Motor_CCW();
            printf("역회전(CCW)\n");
            break;
        case STOP:
            Motor_Stop();
            printf("정지(STOP)\n");
            break;
    }
    motor_state = state;
    motor_speed = 50;       // Motor_CW/CCW는 항상 50%로 초기화됨
    new_motor_speed = 50;   // 이전 UART 요청 속도가 다음 if에서 재적용되지 않도록 동기화
}

// duty: 0~100
void Motor_Set_Duty(int duty)
{
    if(duty < 0)   duty = 0;
    if(duty > 100) duty = 100;

    unsigned int ccr = (unsigned int)(TIM2->ARR * ((double)duty / 100.));

    if(pwm_active_state == CW)
        TIM2->CCR2 = ccr;      // PA1 채널
    else if(pwm_active_state == CCW)
        TIM2->CCR1 = ccr;      // PA0 채널
  
}


extern volatile unsigned char uart_data;

// event만 보고 new_motor_state / new_motor_speed를 계산 (하드웨어 접근 없음)
void Update_Motor_State(void)
{
    volatile ButtonEvent_t event = button_event;
    button_event = BUTTON_NONE;

    new_motor_state = motor_state;
    new_motor_speed = motor_speed;

    switch(motor_state)
    {
        case STOP:
            if(event == BUTTON_SHORT)
                new_motor_state = CW;
            break;
        case CW:
            if(event == BUTTON_SHORT)
                new_motor_state = CCW;
            else if(event == BUTTON_LONG)
                new_motor_state = STOP;
            break;
        case CCW:
            if(event == BUTTON_SHORT)
                new_motor_state = CW;
            else if(event == BUTTON_LONG)
                new_motor_state = STOP;
            break;
    }

    if(event == BUTTON_UART_CMD)
    {
        char ch = (char)uart_data;

        if(ch >= '0' && ch <= '9')
        {
            if(motor_state != STOP)
                new_motor_speed = duty_table[ch - '0'];
        }
        else if(ch == 's' || ch == 'S')
        {
            if(motor_state != STOP)
            {
                printf("[UART] => ");
                new_motor_state = STOP;
            }
        }
        else if(ch == 'f' || ch == 'F')
        {
            if(motor_state != CW)
            {
                printf("[UART] => ");
                new_motor_state = CW;
            }
        }
        else if(ch == 'r' || ch == 'R')
        {
            if(motor_state != CCW)
            {
                printf("[UART] => ");
                new_motor_state = CCW;
            }
        }
    }
}

// new_motor_state / new_motor_speed가 이전 값과 다를 때만 실제 하드웨어에 반영
void Drive_Motor(void)
{
    if(waiting_reverse)
    {
        if(SysTick_Check_Timeout())
        {
            waiting_reverse = 0;
            Apply_Motor_State(pending_state);
        }
        return;   // 대기 중에는 그 외 처리 보류
    }

    if(new_motor_state != motor_state)
    {
        if(motor_state != STOP && new_motor_state != STOP)
        {
            Motor_Wait();
            return;
        }

        Apply_Motor_State(new_motor_state);
    }

    if(new_motor_speed != motor_speed)
    {
        Motor_Set_Duty(new_motor_speed);
        motor_speed = new_motor_speed;
        printf("[UART] => PWM : %d%%\n", motor_speed);
    }
}

