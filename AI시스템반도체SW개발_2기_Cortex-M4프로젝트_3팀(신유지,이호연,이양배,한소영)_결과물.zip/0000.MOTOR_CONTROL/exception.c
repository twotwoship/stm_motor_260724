#include "device_driver.h"
#include <stdio.h>

void _Invalid_ISR(void)
{
	unsigned int r = Macro_Extract_Area(SCB->ICSR, 0x1ff, 0);
	printf("\nInvalid_Exception: %d!\n", r);
	printf("Invalid_ISR: %d!\n", r - 16);
	for(;;);
}

extern volatile int Key_Pressed;
extern volatile int Key_Released;

void EXTI15_10_IRQHandler(void)
{
	EXTI->PR = 0x1 << 13;
	NVIC_ClearPendingIRQ(40);

	for(volatile int i = 0; i < 5000; i++);

	if(Key_Get_Pressed())
	{
		Key_Pressed = 1;
		Key_Released = 0;
	}
	else
	{
		Key_Released = 1;
		Key_Pressed = 0;
	}

}

extern volatile ButtonEvent_t button_event;
extern volatile unsigned char uart_flag;
extern volatile unsigned char uart_data;

void USART2_IRQHandler(void)
{
	char ch = (char)(USART2->DR & 0xFF);   // DR 읽으면 RXNE 자동 클리어
	NVIC_ClearPendingIRQ(38);

	uart_data = (unsigned char)ch;
	uart_flag = 1;
}

void TIM5_IRQHandler(void)
{
	if(Macro_Check_Bit_Set(TIM5->SR, 0))
	{
		Macro_Clear_Bit(TIM5->SR, 0);
		button_event = BUTTON_LONG;
		printf("[BTN] => ");
	}
	// TIM4 Interrupt Pending Clear
	Macro_Clear_Bit(TIM5->SR, 0);
	// NVIC Pending Clear
	NVIC_ClearPendingIRQ(50);

}
