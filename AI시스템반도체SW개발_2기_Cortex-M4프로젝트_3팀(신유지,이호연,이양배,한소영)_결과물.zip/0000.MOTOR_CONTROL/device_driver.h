#include "stm32f4xx.h"
#include "option.h"
#include "macro.h"
#include "malloc.h"

typedef enum
{
    BUTTON_NONE = 0,
    BUTTON_SHORT,
    BUTTON_LONG,
    BUTTON_UART_CMD
} ButtonEvent_t;

typedef enum
{
    STOP = 0,
    CW,
    CCW
} MotorState_t;

extern volatile ButtonEvent_t button_event;
extern volatile MotorState_t motor_state;

// Uart.c
extern void Uart2_Init(int baud);
extern void Uart2_Send_Byte(char data);
extern void Uart2_RX_Interrupt_Enable(void);
extern void Uart_Event_Handle(void);



// Clock.c
extern void Clock_Init(void);

// Key.c
extern void Key_Init(void);
extern int Key_Get_Pressed(void);
extern void Check_Event(void);
extern void Key_ISR_Enable(void);

// Motor.c
extern void Motor_Init(void);
extern void Motor_Pin_Output_Low(int pin);
extern void Motor_Pin_PWM(int pin);
extern void Motor_CW(void);
extern void Motor_CCW(void);
extern void Motor_Stop(void);
extern void Motor_Wait(void);
extern void Update_Motor_State(void);
extern void Drive_Motor(void);
extern void Motor_Set_Duty(int duty);
extern int Motor_Is_Waiting(void);

// Timer.c
extern void TIM5_Init(void);
extern void TIM5_ISR_Enable(void);
extern void TIM5_Start(void);
extern void TIM5_Stop(void);
extern void TIM2_PWM_Init(void);

// Systick.c
extern void SysTick_Run(unsigned int msec);
extern int SysTick_Check_Timeout(void);
extern unsigned int SysTick_Get_Time(void);
extern unsigned int SysTick_Get_Load_Time(void);
extern void SysTick_Stop(void);