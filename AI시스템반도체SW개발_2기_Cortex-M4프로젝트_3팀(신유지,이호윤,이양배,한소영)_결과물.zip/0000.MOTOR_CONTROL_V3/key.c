#include "device_driver.h"
#include <stdio.h>

#define LONG_PRESS_MS   3000

void Key_Init(void)
{
	Macro_Set_Bit(RCC->AHB1ENR, 2); 
	Macro_Write_Block(GPIOC->MODER, 0x3, 0x0, 26);
	Macro_Write_Block(GPIOC->PUPDR, 0x3, 0x1, 26);
}

void Key_ISR_Enable(void)
{
	Macro_Set_Bit(RCC->APB2ENR, 14); 
	Macro_Write_Block(SYSCFG->EXTICR[3], 0xf, 0x2, 4);

	Macro_Set_Bit(EXTI->FTSR, 13);
	Macro_Set_Bit(EXTI->RTSR, 13);
	EXTI->PR = 0x1 << 13;
		
	NVIC_ClearPendingIRQ((IRQn_Type)40);
	Macro_Set_Bit(EXTI->IMR, 13);
	NVIC_EnableIRQ((IRQn_Type)40);
}


volatile int Key_Pressed = 0;
volatile int Key_Released = 0;

static void Button_Event_Handle(void)
{
	static int lock = 0;

	if(lock == 0 && Key_Pressed)
	{
		Key_Pressed = 0;
		lock = 1;
		TIM5_Start();
	}

	else if(lock == 1 && Key_Released)
	{
		Key_Released = 0;
		lock = 0;
		if(Macro_Check_Bit_Set(TIM5->CR1, 0))
		{
			TIM5_Stop();
			event = EVT_BTN_SHORT;
			printf("[BTN] => ");
		}
	}
}

// main 루프에서 호출하는 단일 진입점: 버튼/UART 이벤트를 모두 여기서 소비
void Check_Event(void)
{
	Button_Event_Handle();
	Uart_Event_Handle();
}

int Key_Get_Pressed(void)
{
	return Macro_Check_Bit_Clear(GPIOC->IDR, 13);
}

