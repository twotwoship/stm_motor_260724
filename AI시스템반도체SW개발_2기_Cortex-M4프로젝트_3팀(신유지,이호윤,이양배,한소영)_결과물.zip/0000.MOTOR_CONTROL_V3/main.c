#include "device_driver.h"
#include <stdio.h>

volatile Event_t event = EVT_NONE;
volatile MotorState_t motor_state = STOP;

static void Sys_Init(int baud)
{
	SCB->CPACR |= (0x3 << 10*2)|(0x3 << 11*2);
	Clock_Init();
	Uart2_Init(baud);
	setvbuf(stdout, NULL, _IONBF, 0);
	Key_Init();
	Motor_Init();
	TIM5_Init();
}

void Main(void)
{
	Sys_Init(115200);
	printf("\n*** MOTOR CONTROL ***\n");

	TIM2_PWM_Init();
	Key_ISR_Enable();
	TIM5_ISR_Enable();
	Uart2_RX_Interrupt_Enable();

	for(;;)
	{
		if(!Motor_Is_Waiting())
		{
			Check_Event();
			Update_Motor_State();
		}
		Drive_Motor();
	}
}